package exception;

public class LimitException extends Exception{
    public LimitException(String string){
        super(string);
    }
}