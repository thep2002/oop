package media;
import exception.PlayerException;
public interface Playable {
    public String play() throws PlayerException;
}