package media;

public interface Playable {
    public void play();
}
